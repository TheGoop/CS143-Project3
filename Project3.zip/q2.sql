select country from Affiliations a, Place p where affiliationName="CERN" and a.pid=p.id;
