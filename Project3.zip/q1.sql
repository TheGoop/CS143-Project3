select p.id from Laureates l, Person p where l.id=p.id and p.familyName="Curie" and p.givenName="Marie";
